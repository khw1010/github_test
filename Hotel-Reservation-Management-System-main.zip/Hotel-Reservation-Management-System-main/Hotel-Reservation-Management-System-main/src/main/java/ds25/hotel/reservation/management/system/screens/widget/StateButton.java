package ds25.hotel.reservation.management.system.screens.widget;

import javax.swing.*;

public class StateButton extends JButton {

}
