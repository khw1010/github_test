package ds25.hotel.reservation.management.system.pattern.iterator;

public interface Aggregate {
    public abstract Iterator iterator();
}
