package ds25.hotel.reservation.management.system.entity.hotel;

public enum BedSize {
    SINGLE,
    SUPER_SINGLE,
    DOUBLE,
    TWIN,
    QUEEN,
    KING
}
