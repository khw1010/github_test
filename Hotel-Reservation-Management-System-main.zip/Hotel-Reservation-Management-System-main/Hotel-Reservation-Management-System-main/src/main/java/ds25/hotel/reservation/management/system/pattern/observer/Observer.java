package ds25.hotel.reservation.management.system.pattern.observer;

public interface Observer {
    void update(Observable o, Object arg);
}
