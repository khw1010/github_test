package ds25.hotel.reservation.management.system.screens.widget;

import javax.swing.*;

public class EastPanel extends JPanel {

    public EastPanel(){
        this.setBorder(BorderFactory.createEmptyBorder(10,50,10,50));
    }
}
