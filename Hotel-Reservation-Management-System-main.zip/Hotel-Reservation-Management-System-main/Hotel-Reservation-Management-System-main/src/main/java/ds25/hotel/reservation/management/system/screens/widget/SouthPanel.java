package ds25.hotel.reservation.management.system.screens.widget;

import javax.swing.*;

public class SouthPanel extends JPanel {
    public SouthPanel() {
        JLabel label = new JLabel("© DS25 Team, Hotel Reservation Management System. All rights reserved.");
        add(label);
    }
}
