package ds25.hotel.reservation.management.system.entity.user;

public enum UserRole {
    ADMIN,
    USER
}
