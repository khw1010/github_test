package ds25.hotel.reservation.management.system.screens.widget;

import javax.swing.*;

public class WestPanel extends JPanel {

    public WestPanel(){
        this.setBorder(BorderFactory.createEmptyBorder(10,50,10,50));
    }
}
